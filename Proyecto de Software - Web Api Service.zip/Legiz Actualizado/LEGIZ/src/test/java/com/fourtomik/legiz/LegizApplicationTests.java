package com.fourtomik.legiz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LegizApplicationTests {

    @Test
    void contextLoads() {
    }

}
